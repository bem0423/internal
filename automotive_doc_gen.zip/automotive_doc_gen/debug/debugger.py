"""
debug/debugger.py
-----------------
Centralised debug logger for every pipeline module.
Each module calls DebugPoint at key moments.

Usage:
    from debug.debugger import DebugPoint
    DebugPoint.log_input("M1_CLASSIFIER", payload)
    DebugPoint.log_prompt("M1_CLASSIFIER", system_prompt, user_prompt)
    DebugPoint.log_raw_response("M1_CLASSIFIER", raw_text)
    DebugPoint.log_output("M1_CLASSIFIER", parsed_result)
    DebugPoint.log_error("M1_CLASSIFIER", exception)
"""

import json
import time
import traceback
from datetime import datetime
from pathlib import Path
from config import PIPELINE


# ── Pretty colours for terminal ──────────────────────────

RESET  = "\033[0m"
BOLD   = "\033[1m"
CYAN   = "\033[96m"
YELLOW = "\033[93m"
GREEN  = "\033[92m"
RED    = "\033[91m"
GRAY   = "\033[90m"
BLUE   = "\033[94m"
ORANGE = "\033[38;5;214m"


def _header(module: str, label: str, color: str) -> str:
    ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
    return f"\n{color}{BOLD}{'─'*60}\n[{ts}]  {module}  ▸  {label}\n{'─'*60}{RESET}"


def _json(obj) -> str:
    try:
        if hasattr(obj, "model_dump"):
            return json.dumps(obj.model_dump(), indent=2, ensure_ascii=False)
        return json.dumps(obj, indent=2, ensure_ascii=False)
    except Exception:
        return str(obj)


# ── Log file (optional) ──────────────────────────────────

LOG_DIR = Path("debug/logs")
LOG_DIR.mkdir(parents=True, exist_ok=True)
_log_file = LOG_DIR / f"pipeline_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"


def _write_log(text: str):
    """Append to log file (strips ANSI codes)."""
    import re
    clean = re.sub(r'\033\[[0-9;]*m', '', text)
    with open(_log_file, "a", encoding="utf-8") as f:
        f.write(clean + "\n")


def _print_and_log(text: str):
    if PIPELINE.debug:
        print(text)
    _write_log(text)


# ── DebugPoint class ─────────────────────────────────────

class DebugPoint:

    # ① Input received by the module
    @staticmethod
    def log_input(module: str, payload: object):
        msg = _header(module, "INPUT", CYAN)
        msg += f"\n{_json(payload)}"
        _print_and_log(msg)

    # ② System + User prompts sent to LLM
    @staticmethod
    def log_prompt(module: str, system_prompt: str, user_prompt: str):
        msg = _header(module, "PROMPT SENT TO LLM", YELLOW)
        msg += f"\n{BOLD}[SYSTEM PROMPT]{RESET}\n{GRAY}{system_prompt}{RESET}"
        msg += f"\n\n{BOLD}[USER PROMPT]{RESET}\n{GRAY}{user_prompt}{RESET}"
        _print_and_log(msg)

    # ③ Raw LLM response (before parsing)
    @staticmethod
    def log_raw_response(module: str, raw: str, token_usage: dict = None):
        msg = _header(module, "RAW LLM RESPONSE", ORANGE)
        msg += f"\n{raw}"
        if token_usage:
            msg += f"\n\n{GRAY}Tokens → {token_usage}{RESET}"
        _print_and_log(msg)

    # ④ Parsed / structured output
    @staticmethod
    def log_output(module: str, result: object):
        msg = _header(module, "PARSED OUTPUT ✓", GREEN)
        msg += f"\n{_json(result)}"
        _print_and_log(msg)

    # ⑤ RAG API call details
    @staticmethod
    def log_rag_request(endpoint: str, payload: dict):
        msg = _header("M3_RAG_RETRIEVER", "RAG API REQUEST", BLUE)
        msg += f"\nEndpoint: {endpoint}"
        msg += f"\nPayload:\n{json.dumps(payload, indent=2, ensure_ascii=False)}"
        _print_and_log(msg)

    # ⑥ RAG API response
    @staticmethod
    def log_rag_response(chunks: list, elapsed_ms: float):
        msg = _header("M3_RAG_RETRIEVER", f"RAG API RESPONSE  ({elapsed_ms:.0f}ms)", BLUE)
        msg += f"\nChunks returned: {len(chunks)}"
        for i, c in enumerate(chunks):
            msg += f"\n  [{i+1}] src_id={c.get('src_id','?')}  score={c.get('relevance_score','?'):.3f}"
        _print_and_log(msg)

    # ⑦ Validation gate decision
    @staticmethod
    def log_cert_gate(passed: bool, confidence: float, issues: list):
        color = GREEN if passed else RED
        label = "CERT GATE → PASS ✓" if passed else "CERT GATE → FAIL ✗"
        msg = _header("M5_VALIDATOR", label, color)
        msg += f"\nConfidence score: {confidence:.2f}"
        msg += f"\nIssues: {len(issues)}"
        for issue in issues:
            icon = "⚠" if issue['severity'] == "WARNING" else "✗"
            msg += f"\n  {icon}  [{issue['severity']}] {issue['description']}"
        _print_and_log(msg)

    # ⑧ Error
    @staticmethod
    def log_error(module: str, exc: Exception):
        msg = _header(module, "ERROR ✗", RED)
        msg += f"\n{RED}{traceback.format_exc()}{RESET}"
        _print_and_log(msg)

    # ⑨ Pipeline step timing
    @staticmethod
    def log_timing(module: str, elapsed_ms: float):
        msg = f"{GRAY}  ⏱  {module} completed in {elapsed_ms:.0f}ms{RESET}"
        _print_and_log(msg)

    # ⑩ Pipeline summary at end
    @staticmethod
    def log_pipeline_summary(req_id: str, steps: list[dict]):
        msg = _header("PIPELINE", "SUMMARY", GREEN)
        total = sum(s['ms'] for s in steps)
        for s in steps:
            status = "✓" if s['ok'] else "✗"
            msg += f"\n  {status}  {s['module']:<30} {s['ms']:>6.0f}ms"
        msg += f"\n{'─'*46}"
        msg += f"\n  Total: {total:.0f}ms   REQ-ID: {req_id}"
        _print_and_log(msg)
