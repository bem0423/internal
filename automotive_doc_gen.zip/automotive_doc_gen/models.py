"""
models.py
---------
Shared Pydantic data models for the entire pipeline.
All inter-module data is typed and validated here.
"""

from pydantic import BaseModel, Field
from typing import Optional
from enum import Enum


# ──────────────────────────────────────────
# Enums
# ──────────────────────────────────────────

class Domain(str, Enum):
    ASPICE    = "ASPICE"
    ISO_26262 = "ISO_26262"
    ISO_21434 = "ISO_21434"


class AspiceSubCategory(str, Enum):
    SWE1  = "SWE.1"
    SWE2  = "SWE.2"
    SWE3  = "SWE.3"
    SWE4  = "SWE.4"
    SWE5  = "SWE.5"
    SWE6  = "SWE.6"
    MAN3  = "MAN.3"
    SUP1  = "SUP.1"
    OTHER = "OTHER"

class Iso26262SubCategory(str, Enum):
    CONCEPT         = "Concept"
    HARA            = "HARA"
    FSC             = "FSC"
    TSR             = "TSR"
    SW_REQUIREMENTS = "SWRequirements"
    SW_ARCHITECTURE = "SWArchitecture"
    VERIFICATION    = "Verification"
    OTHER           = "OTHER"

class Iso21434SubCategory(str, Enum):
    TARA                 = "TARA"
    CYBERSECURITY_GOALS  = "CybersecurityGoals"
    CAL                  = "CAL"
    ATTACK_PATH          = "AttackPath"
    MONITORING_RESPONSE  = "MonitoringResponse"
    OTHER                = "OTHER"

class ValidationStatus(str, Enum):
    PASS    = "PASS"
    WARNING = "WARNING"
    FAIL    = "FAIL"


# ──────────────────────────────────────────
# Module 1 Output — Classification Result
# ──────────────────────────────────────────

class ClassificationResult(BaseModel):
    domain: Domain
    sub_category: str               # One of the sub-category enums above
    confidence: float = Field(ge=0.0, le=1.0)
    reasoning: str
    req_id: Optional[str] = None    # Auto-assigned request ID


# ──────────────────────────────────────────
# Module 2 Output — RAG Query
# ──────────────────────────────────────────

class RAGQuery(BaseModel):
    query: str
    filters: dict                   # { "domain": ..., "sub_category": ... }
    top_k: int = 5


# ──────────────────────────────────────────
# Module 3 Output — RAG Retrieved Context
# ──────────────────────────────────────────

class RAGSourceChunk(BaseModel):
    src_id: str                     # e.g. "SRC-TMPL-0042"
    source_type: str                # "JEDEC" | "PREV" | "TMPL" | "PROC"
    content: str
    relevance_score: float


class RAGContext(BaseModel):
    chunks: list[RAGSourceChunk]
    assembled_text: str             # Joined context for LLM
    source_ids: list[str]           # All SRC-IDs for traceability


# ──────────────────────────────────────────
# Module 4 Output — Generated Document
# ──────────────────────────────────────────

class DocumentSection(BaseModel):
    ref_id: str                     # e.g. "§REF-001"
    title: str
    content: str
    source_ids: list[str]           # Which SRC-IDs were used


class GeneratedDocument(BaseModel):
    req_id: str
    domain: Domain
    sub_category: str
    sections: list[DocumentSection]
    fill_gaps: list[str]            # List of <<<FILL: ...>>> items found
    prompt_version: str
    model_used: str
    raw_markdown: str               # Full document as markdown string


# ──────────────────────────────────────────
# Module 5 Output — Validation Result
# ──────────────────────────────────────────

class ValidationIssue(BaseModel):
    severity: str                   # "ERROR" | "WARNING" | "INFO"
    section_ref_id: Optional[str]
    description: str


class ValidationResult(BaseModel):
    status: ValidationStatus
    confidence_score: float = Field(ge=0.0, le=1.0)
    issues: list[ValidationIssue]
    fill_gap_count: int
    missing_source_refs: list[str]
    passed_certification_gate: bool
    summary: str


# ──────────────────────────────────────────
# Full Pipeline State (passed between modules)
# ──────────────────────────────────────────

class PipelineState(BaseModel):
    user_prompt: str
    req_id: str

    # Filled progressively by each module
    classification: Optional[ClassificationResult] = None
    rag_query: Optional[RAGQuery]                  = None
    rag_context: Optional[RAGContext]              = None
    document: Optional[GeneratedDocument]          = None
    validation: Optional[ValidationResult]         = None
