# Automotive AI Document Generation Pipeline

## Quick Start

```bash
pip install -r requirements.txt

# Set your API keys
export LLM_BASE_URL="https://your-openai-compatible-url/v1"
export LLM_API_KEY="your-key"
export LLM_MODEL="gpt-4o"
export RAG_BASE_URL="https://your-rag-api/v1"
export RAG_API_KEY="your-rag-key"

# Run pipeline
python pipeline.py --prompt "Create HARA document for BMS system"

# Disable debug output
DEBUG=false python pipeline.py --prompt "..."
```

---

## File Structure

```
automotive_doc_gen/
├── config.py                  ← API keys, thresholds, prompt versions
├── models.py                  ← All Pydantic data models
├── pipeline.py                ← Main runner (entry point)
├── requirements.txt
├── prompts/
│   ├── classifier_prompt.py   ← M1 system prompt
│   ├── rag_query_prompt.py    ← M2 system prompt
│   ├── generator_prompt.py    ← M3 system prompt + user prompt builder
│   └── validator_prompt.py    ← M4 system prompt + user prompt builder
├── modules/
│   ├── llm_client.py          ← Shared LLM HTTP client
│   ├── m1_classifier.py       ← Domain classifier
│   ├── m2_rag_query.py        ← RAG query builder
│   ├── m3_rag_retriever.py    ← RAG API caller  ← STUB HERE
│   ├── m4_generator.py        ← Document generator
│   └── m5_validator.py        ← Auto validator / cert gate
└── debug/
    ├── debugger.py            ← All debug points
    └── logs/                  ← Auto-generated log files
```

---

## Debug Points (per module)

Every module has numbered debug points. With `DEBUG=true` (default), all are
printed to terminal AND saved to `debug/logs/pipeline_YYYYMMDD_HHMMSS.log`.

| Point | What it shows |
|-------|---------------|
| ① INPUT          | Data entering the module |
| ② PROMPT         | System + user prompt sent to LLM |
| ③ RAW RESPONSE   | Raw text/JSON from LLM (before parsing) |
| ④ OUTPUT         | Parsed, validated output |
| ⑤ RAG REQUEST    | HTTP payload sent to RAG API |
| ⑥ RAG RESPONSE   | Chunks returned from RAG |
| ⑦ CERT GATE      | PASS/FAIL decision with all issues listed |
| ⑧ TIMING         | ms elapsed per module |
| ⑨ PIPELINE SUMMARY | Full run summary table |

---

## RAG API Integration

Open `modules/m3_rag_retriever.py` and find the comment:

```python
# ── RAG API CALL ──
STUB_MODE = True   # ← set to False when your RAG API is ready
```

Replace the stub block with your actual `httpx` call.
Your RAG API must return a list of chunks in this format:

```json
[
  {
    "src_id": "SRC-TMPL-0042",
    "source_type": "TEMPLATES",
    "content": "...",
    "relevance_score": 0.91
  }
]
```

---

## Changing Prompts

All prompts are in `prompts/`. Edit freely.
Bump the version in `config.py` when you change a prompt:

```python
generator_prompt_version: str = "v1.1"   # ← increment here
```

The version is logged in every generated document for full audit traceability.

---

## Pipeline Data Flow

```
user_prompt
    │
    ▼
M1_CLASSIFIER    → ClassificationResult  (domain, sub_cat, confidence)
    │
    ▼
M2_RAG_QUERY     → RAGQuery             (query string, filters, top_k)
    │
    ▼
M3_RAG_RETRIEVER → RAGContext           (chunks, assembled_text, SRC-IDs)
    │
    ▼
M4_GENERATOR     → GeneratedDocument    (sections, §REF-IDs, fill_gaps)
    │
    ▼
M5_VALIDATOR     → ValidationResult    (PASS/FAIL, issues, cert gate)
    │
    ▼
output/{REQ-ID}_{domain}_{sub_cat}.md
```
