"""
config.py
---------
Central configuration for the entire pipeline.
Edit this file to switch models, endpoints, or thresholds.
"""

import os
from dataclasses import dataclass


@dataclass
class LLMConfig:
    # Your OpenAI-compatible endpoint
    base_url: str  = os.getenv("LLM_BASE_URL", "https://your-openai-compatible-url/v1")
    api_key: str   = os.getenv("LLM_API_KEY",  "your-api-key-here")
    model: str     = os.getenv("LLM_MODEL",    "gpt-4o")
    temperature: float = 0.0
    max_tokens: int    = 4096


@dataclass
class RAGConfig:
    # Your on-premise RAG API endpoint
    # ─── REPLACE THIS SECTION WITH YOUR ACTUAL RAG API ───────────────
    base_url: str     = os.getenv("RAG_BASE_URL", "https://your-rag-api/v1")
    api_key: str      = os.getenv("RAG_API_KEY",  "your-rag-key-here")
    retrieve_path: str = "/retrieve"      # POST endpoint for retrieval
    top_k: int         = 5
    timeout_sec: int   = 30
    # ──────────────────────────────────────────────────────────────────


@dataclass
class PipelineConfig:
    # Prompt versions — increment when you change a prompt
    classifier_prompt_version: str  = "v1.0"
    rag_query_prompt_version: str   = "v1.0"
    generator_prompt_version: str   = "v1.0"
    validator_prompt_version: str   = "v1.0"

    # Validation thresholds
    min_confidence_threshold: float = 0.70   # Below this → reject at cert gate
    max_fill_gaps_allowed: int      = 5       # More gaps than this → WARNING

    # Debug mode: prints full prompts and raw LLM responses
    debug: bool = bool(os.getenv("DEBUG", "true"))


# ── Singletons ──────────────────────────────────────────
LLM    = LLMConfig()
RAG    = RAGConfig()
PIPELINE = PipelineConfig()
