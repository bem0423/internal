"""
modules/m2_rag_query.py
-----------------------
MODULE 2 — RAG Query Builder

Input  : PipelineState with classification filled
Output : RAGQuery added to PipelineState

Debug points:
  ① log_input   — classification result
  ② log_prompt  — prompts sent to LLM           [in llm_client]
  ③ log_raw     — raw JSON from LLM             [in llm_client]
  ④ log_output  — parsed RAGQuery
"""

import time
from models import RAGQuery, PipelineState
from modules.llm_client import llm
from prompts.rag_query_prompt import RAG_QUERY_SYSTEM_PROMPT
from debug.debugger import DebugPoint


MODULE = "M2_RAG_QUERY"


def run(state: PipelineState) -> PipelineState:
    t0 = time.time()

    assert state.classification is not None, "M1 must run before M2"

    cls = state.classification

    # ── DEBUG POINT ①: input ────────────────────────────────────────
    DebugPoint.log_input(MODULE, cls)

    user_prompt = (
        f"Domain: {cls.domain}\n"
        f"Sub-category: {cls.sub_category}\n"
        f"User request: {state.user_prompt}"
    )

    try:
        raw, _tokens = llm.call(MODULE, RAG_QUERY_SYSTEM_PROMPT, user_prompt)
        data = llm.parse_json(raw)

        result = RAGQuery(
            query   = data["query"],
            filters = data.get("filters", {}),
            top_k   = int(data.get("top_k", 5)),
        )

        # ── DEBUG POINT ④: parsed output ────────────────────────────
        DebugPoint.log_output(MODULE, result)

        state.rag_query = result

    except Exception as e:
        DebugPoint.log_error(MODULE, e)
        raise

    DebugPoint.log_timing(MODULE, (time.time() - t0) * 1000)
    return state
