"""
modules/m3_rag_retriever.py
---------------------------
MODULE 3 — RAG Retriever

Calls your on-premise RAG API and assembles the context.

Input  : PipelineState with rag_query filled
Output : RAGContext added to PipelineState

Debug points:
  ① log_input        — RAGQuery
  ② log_rag_request  — HTTP request to RAG API
  ③ log_rag_response — chunks returned
  ④ log_output       — assembled RAGContext

═══════════════════════════════════════════════════════════
  ⚑  RAG API INTEGRATION — REPLACE THE STUB BELOW
     Search for the comment block: # ── RAG API CALL ──
     Replace the stub response with your actual API call.
═══════════════════════════════════════════════════════════
"""

import time
import httpx
from models import RAGContext, RAGSourceChunk, PipelineState, RAGQuery
from debug.debugger import DebugPoint
from config import RAG


MODULE = "M3_RAG_RETRIEVER"


# ──────────────────────────────────────────────────────────────────────────────
# ⚑  RAG API CALL  ──  REPLACE THIS FUNCTION WITH YOUR ACTUAL API INTEGRATION
# ──────────────────────────────────────────────────────────────────────────────
def _call_rag_api(query: RAGQuery) -> list[dict]:
    """
    Call the on-premise RAG API and return a list of chunk dicts.

    Expected response format from your RAG API:
    [
        {
            "src_id": "SRC-TMPL-0042",
            "source_type": "TEMPLATES",
            "content": "...",
            "relevance_score": 0.91
        },
        ...
    ]

    ─── REPLACE BELOW WITH YOUR ACTUAL HTTP CALL ────────────────────────
    """

    endpoint = f"{RAG.base_url}{RAG.retrieve_path}"

    payload = {
        "query":   query.query,
        "filters": query.filters,
        "top_k":   query.top_k,
    }

    # ── DEBUG POINT ②: log the request before sending ─────────────────
    DebugPoint.log_rag_request(endpoint, payload)

    # ┌─────────────────────────────────────────────────────────────────┐
    # │  STUB — returns fake chunks so the pipeline can run end-to-end  │
    # │  Replace this block with your actual httpx / requests call.     │
    # └─────────────────────────────────────────────────────────────────┘
    STUB_MODE = True   # ← set to False when your RAG API is ready

    if STUB_MODE:
        print(f"\n[{MODULE}]  ⚠  STUB MODE — returning fake RAG chunks")
        print(f"[{MODULE}]     Endpoint that WILL be called: {endpoint}")
        print(f"[{MODULE}]     Payload: {payload}\n")
        return [
            {
                "src_id": "SRC-TMPL-0001",
                "source_type": "TEMPLATES",
                "content": (
                    "# Software Architecture Description\n"
                    "## §1 Scope\n[Template: describe the system scope here]\n"
                    "## §2 Architectural Design\n[Template: describe components]\n"
                    "## §3 Interface Definition\n[Template: list interfaces]\n"
                    "## §4 Dynamic Behaviour\n[Template: describe state machines]\n"
                    "## §5 Data Types and Global Data\n[Template: list data types]\n"
                    "## §6 Traceability\n[Template: link to SW requirements]"
                ),
                "relevance_score": 0.95,
            },
            {
                "src_id": "SRC-PREV-0023",
                "source_type": "PREVIOUS_DOCS",
                "content": (
                    "BMS architecture used CAN bus at 500kbps. "
                    "Cell voltage monitoring at 10ms cycle. "
                    "ASIL-B decomposition applied to balancing controller."
                ),
                "relevance_score": 0.87,
            },
            {
                "src_id": "SRC-PROC-0005",
                "source_type": "PROCESS_GUIDES",
                "content": (
                    "SW Architecture review checklist SWE.3:\n"
                    "- All interfaces defined with direction and data type\n"
                    "- ASIL level assigned to each component\n"
                    "- Timing constraints documented"
                ),
                "relevance_score": 0.78,
            },
        ]

    # ─── YOUR ACTUAL RAG API CALL GOES HERE ──────────────────────────
    # headers = {
    #     "Authorization": f"Bearer {RAG.api_key}",
    #     "Content-Type": "application/json",
    # }
    # with httpx.Client(timeout=RAG.timeout_sec) as client:
    #     resp = client.post(endpoint, headers=headers, json=payload)
    # resp.raise_for_status()
    # return resp.json()   # must be list[dict] matching format above
    # ─────────────────────────────────────────────────────────────────


# ──────────────────────────────────────────────────────────────────────────────
# Module runner
# ──────────────────────────────────────────────────────────────────────────────

def run(state: PipelineState) -> PipelineState:
    t0 = time.time()

    assert state.rag_query is not None, "M2 must run before M3"

    # ── DEBUG POINT ①: input ────────────────────────────────────────
    DebugPoint.log_input(MODULE, state.rag_query)

    try:
        t_api = time.time()
        raw_chunks = _call_rag_api(state.rag_query)
        elapsed_api_ms = (time.time() - t_api) * 1000

        # ── DEBUG POINT ③: RAG response ─────────────────────────────
        DebugPoint.log_rag_response(raw_chunks, elapsed_api_ms)

        # Parse chunks into typed models
        chunks = [RAGSourceChunk(**c) for c in raw_chunks]

        # Assemble context text for the generator
        assembled = "\n\n---\n\n".join(
            f"[{c.src_id}] ({c.source_type})\n{c.content}"
            for c in chunks
        )
        source_ids = [c.src_id for c in chunks]

        result = RAGContext(
            chunks         = chunks,
            assembled_text = assembled,
            source_ids     = source_ids,
        )

        # ── DEBUG POINT ④: output ───────────────────────────────────
        DebugPoint.log_output(MODULE, {
            "chunk_count": len(chunks),
            "source_ids":  source_ids,
            "assembled_length_chars": len(assembled),
        })

        state.rag_context = result

    except Exception as e:
        DebugPoint.log_error(MODULE, e)
        raise

    DebugPoint.log_timing(MODULE, (time.time() - t0) * 1000)
    return state
