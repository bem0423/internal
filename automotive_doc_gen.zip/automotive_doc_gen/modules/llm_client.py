"""
modules/llm_client.py
---------------------
Shared LLM client for all modules.
Calls your OpenAI-compatible endpoint.
"""

import json
import time
import httpx
from config import LLM
from debug.debugger import DebugPoint


class LLMClient:

    def __init__(self):
        self.base_url  = LLM.base_url.rstrip("/")
        self.api_key   = LLM.api_key
        self.model     = LLM.model
        self.temperature = LLM.temperature
        self.max_tokens  = LLM.max_tokens

    def call(
        self,
        module_name: str,
        system_prompt: str,
        user_prompt: str,
    ) -> tuple[str, dict]:
        """
        Send a chat completion request.

        Returns:
            (raw_text: str, token_usage: dict)
        """
        # ── DEBUG POINT ①: log the prompts before sending ──────────
        DebugPoint.log_prompt(module_name, system_prompt, user_prompt)

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }
        payload = {
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user",   "content": user_prompt},
            ],
        }

        t0 = time.time()
        with httpx.Client(timeout=60) as client:
            resp = client.post(
                f"{self.base_url}/chat/completions",
                headers=headers,
                json=payload,
            )
        elapsed_ms = (time.time() - t0) * 1000

        resp.raise_for_status()
        data = resp.json()

        raw_text    = data["choices"][0]["message"]["content"]
        token_usage = data.get("usage", {})

        # ── DEBUG POINT ②: log raw response ────────────────────────
        DebugPoint.log_raw_response(module_name, raw_text, token_usage)
        DebugPoint.log_timing(module_name, elapsed_ms)

        return raw_text, token_usage

    @staticmethod
    def parse_json(raw_text: str) -> dict:
        """
        Strip markdown fences and parse JSON.
        Raises ValueError if parsing fails.
        """
        cleaned = raw_text.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("\n", 1)[-1]
            cleaned = cleaned.rsplit("```", 1)[0]
        return json.loads(cleaned.strip())


# Singleton
llm = LLMClient()
