"""
modules/m4_generator.py
-----------------------
MODULE 4 — Document Generator

Input  : PipelineState with rag_context filled
Output : GeneratedDocument added to PipelineState

Debug points:
  ① log_input  — domain, sub_cat, rag context summary
  ② log_prompt — prompts sent to LLM              [in llm_client]
  ③ log_raw    — raw Markdown from LLM            [in llm_client]
  ④ log_output — parsed GeneratedDocument summary
"""

import re
import time
from models import GeneratedDocument, DocumentSection, PipelineState
from modules.llm_client import llm
from prompts.generator_prompt import (
    GENERATOR_SYSTEM_PROMPT,
    build_generator_user_prompt,
)
from debug.debugger import DebugPoint
from config import PIPELINE


MODULE = "M4_GENERATOR"


def _parse_sections(markdown: str) -> list[DocumentSection]:
    """
    Extract §REF-NNN sections from generated markdown.
    Looks for headings that start with §REF-
    """
    sections = []
    pattern = re.compile(r'^(#{1,3})\s*(§REF-\d+[^\n]*)', re.MULTILINE)
    matches = list(pattern.finditer(markdown))

    for i, match in enumerate(matches):
        ref_id = re.search(r'§REF-\d+', match.group(2)).group(0)
        title  = match.group(2).strip()

        # Content is text until next heading
        start = match.end()
        end   = matches[i + 1].start() if i + 1 < len(matches) else len(markdown)
        content = markdown[start:end].strip()

        # Collect SRC-IDs referenced in this section
        src_ids = re.findall(r'\[SRC-[A-Z]+-\d+\]', content)
        src_ids = list(dict.fromkeys(src_ids))  # deduplicate, preserve order

        sections.append(DocumentSection(
            ref_id     = ref_id,
            title      = title,
            content    = content,
            source_ids = src_ids,
        ))

    return sections


def _extract_fill_gaps(markdown: str) -> list[str]:
    """Find all <<<FILL: ...>>> placeholders."""
    return re.findall(r'<<<FILL:[^>]+>>>', markdown)


def _strip_meta_block(markdown: str) -> tuple[str, dict]:
    """
    Remove the GENERATION_META block from the end of the document.
    Returns (clean_markdown, meta_dict).
    """
    meta = {}
    pattern = re.compile(r'---\s*\nGENERATION_META:(.*?)---', re.DOTALL)
    match = pattern.search(markdown)
    if match:
        for line in match.group(1).strip().splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                meta[k.strip()] = v.strip()
        markdown = markdown[:match.start()].rstrip()
    return markdown, meta


def run(state: PipelineState) -> PipelineState:
    t0 = time.time()

    assert state.rag_context   is not None, "M3 must run before M4"
    assert state.classification is not None, "M1 must run before M4"

    cls = state.classification
    ctx = state.rag_context

    # ── DEBUG POINT ①: input ────────────────────────────────────────
    DebugPoint.log_input(MODULE, {
        "domain":        cls.domain,
        "sub_category":  cls.sub_category,
        "source_ids":    ctx.source_ids,
        "rag_chars":     len(ctx.assembled_text),
    })

    user_prompt = build_generator_user_prompt(
        domain       = cls.domain,
        sub_category = cls.sub_category,
        user_request = state.user_prompt,
        rag_context  = ctx.assembled_text,
        source_ids   = ctx.source_ids,
    )

    try:
        raw, _tokens = llm.call(MODULE, GENERATOR_SYSTEM_PROMPT, user_prompt)

        clean_markdown, meta = _strip_meta_block(raw)
        sections  = _parse_sections(clean_markdown)
        fill_gaps = _extract_fill_gaps(clean_markdown)

        result = GeneratedDocument(
            req_id         = state.req_id,
            domain         = cls.domain,
            sub_category   = cls.sub_category,
            sections       = sections,
            fill_gaps      = fill_gaps,
            prompt_version = PIPELINE.generator_prompt_version,
            model_used     = llm.model,
            raw_markdown   = clean_markdown,
        )

        # ── DEBUG POINT ④: output summary ───────────────────────────
        DebugPoint.log_output(MODULE, {
            "sections_count":  len(sections),
            "fill_gaps_count": len(fill_gaps),
            "fill_gaps":       fill_gaps,
            "meta_from_llm":   meta,
        })

        if fill_gaps:
            print(f"[{MODULE}]  ⚠  {len(fill_gaps)} gap(s) need manual fill:")
            for gap in fill_gaps:
                print(f"           → {gap}")

        state.document = result

    except Exception as e:
        DebugPoint.log_error(MODULE, e)
        raise

    DebugPoint.log_timing(MODULE, (time.time() - t0) * 1000)
    return state
