"""
modules/m5_validator.py
-----------------------
MODULE 5 — Auto Validator (Certification Gate)

Input  : PipelineState with document filled
Output : ValidationResult added to PipelineState

Debug points:
  ① log_input    — document summary
  ② log_prompt   — prompts sent to LLM            [in llm_client]
  ③ log_raw      — raw JSON from LLM              [in llm_client]
  ④ log_cert_gate — PASS / FAIL decision with issues
  ⑤ log_output   — full ValidationResult
"""

import time
from models import ValidationResult, ValidationIssue, ValidationStatus, PipelineState
from modules.llm_client import llm
from prompts.validator_prompt import VALIDATOR_SYSTEM_PROMPT, build_validator_user_prompt
from debug.debugger import DebugPoint
from config import PIPELINE


MODULE = "M5_VALIDATOR"


def run(state: PipelineState) -> PipelineState:
    t0 = time.time()

    assert state.document    is not None, "M4 must run before M5"
    assert state.rag_context is not None, "M3 must run before M5"
    assert state.classification is not None

    doc = state.document
    cls = state.classification
    ctx = state.rag_context

    # ── DEBUG POINT ①: input ────────────────────────────────────────
    DebugPoint.log_input(MODULE, {
        "domain":          cls.domain,
        "sub_category":    cls.sub_category,
        "sections_count":  len(doc.sections),
        "fill_gaps_count": len(doc.fill_gaps),
        "source_ids":      ctx.source_ids,
        "doc_chars":       len(doc.raw_markdown),
    })

    user_prompt = build_validator_user_prompt(
        domain            = cls.domain,
        sub_category      = cls.sub_category,
        document_markdown = doc.raw_markdown,
        source_ids        = ctx.source_ids,
    )

    try:
        raw, _tokens = llm.call(MODULE, VALIDATOR_SYSTEM_PROMPT, user_prompt)
        data = llm.parse_json(raw)

        issues = [ValidationIssue(**i) for i in data.get("issues", [])]

        result = ValidationResult(
            status                  = ValidationStatus(data["status"]),
            confidence_score        = float(data["confidence_score"]),
            passed_certification_gate = bool(data["passed_certification_gate"]),
            fill_gap_count          = int(data["fill_gap_count"]),
            missing_source_refs     = data.get("missing_source_refs", []),
            issues                  = issues,
            summary                 = data.get("summary", ""),
        )

        # ── DEBUG POINT ④: certification gate decision ───────────────
        DebugPoint.log_cert_gate(
            passed     = result.passed_certification_gate,
            confidence = result.confidence_score,
            issues     = [i.model_dump() for i in issues],
        )

        # ── DEBUG POINT ⑤: full output ───────────────────────────────
        DebugPoint.log_output(MODULE, result)

        state.validation = result

    except Exception as e:
        DebugPoint.log_error(MODULE, e)
        raise

    DebugPoint.log_timing(MODULE, (time.time() - t0) * 1000)
    return state
