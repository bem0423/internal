"""
modules/m1_classifier.py
------------------------
MODULE 1 — Domain Classifier

Input  : user_prompt (str)
Output : ClassificationResult

Debug points:
  ① log_input   — raw user prompt
  ② log_prompt  — system + user prompt sent to LLM  [in llm_client]
  ③ log_raw     — raw JSON string from LLM           [in llm_client]
  ④ log_output  — parsed ClassificationResult
"""

import uuid
import time
from models import ClassificationResult, PipelineState
from modules.llm_client import llm
from prompts.classifier_prompt import CLASSIFIER_SYSTEM_PROMPT
from debug.debugger import DebugPoint
from config import PIPELINE


MODULE = "M1_CLASSIFIER"


def run(state: PipelineState) -> PipelineState:
    t0 = time.time()

    # ── DEBUG POINT ①: input ────────────────────────────────────────
    DebugPoint.log_input(MODULE, {"user_prompt": state.user_prompt})

    user_prompt = f'User request: "{state.user_prompt}"'

    try:
        raw, _tokens = llm.call(MODULE, CLASSIFIER_SYSTEM_PROMPT, user_prompt)
        data = llm.parse_json(raw)

        # Validate confidence — flag if too low
        confidence = float(data.get("confidence", 0))
        if confidence < PIPELINE.min_confidence_threshold:
            print(
                f"[{MODULE}] ⚠  Confidence {confidence:.2f} is below threshold "
                f"{PIPELINE.min_confidence_threshold}. Flagged for manual review."
            )

        result = ClassificationResult(
            domain       = data["domain"],
            sub_category = data["sub_category"],
            confidence   = confidence,
            reasoning    = data.get("reasoning", ""),
            req_id       = state.req_id,
        )

        # ── DEBUG POINT ④: parsed output ────────────────────────────
        DebugPoint.log_output(MODULE, result)

        state.classification = result

    except Exception as e:
        DebugPoint.log_error(MODULE, e)
        raise

    DebugPoint.log_timing(MODULE, (time.time() - t0) * 1000)
    return state
