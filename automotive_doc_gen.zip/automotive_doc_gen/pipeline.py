"""
pipeline.py
-----------
Main pipeline runner.

Runs all modules in sequence:
  M1 → M2 → M3 → M4 → M5

Usage:
    python pipeline.py
    python pipeline.py --prompt "Create HARA document for BMS system"
    DEBUG=false python pipeline.py   # suppress debug output
"""

import uuid
import time
import argparse
from pathlib import Path
from datetime import datetime

from models import PipelineState
from modules import m1_classifier, m2_rag_query, m3_rag_retriever, m4_generator, m5_validator
from debug.debugger import DebugPoint


# ──────────────────────────────────────────────────────────────────────────────
# Pipeline definition
# ──────────────────────────────────────────────────────────────────────────────

MODULES = [
    ("M1_CLASSIFIER",     m1_classifier.run),
    ("M2_RAG_QUERY",      m2_rag_query.run),
    ("M3_RAG_RETRIEVER",  m3_rag_retriever.run),
    ("M4_GENERATOR",      m4_generator.run),
    ("M5_VALIDATOR",      m5_validator.run),
]


def run_pipeline(user_prompt: str) -> PipelineState:
    """
    Execute the full pipeline for a given user prompt.

    Returns the final PipelineState with all module outputs filled.
    Raises on first unrecoverable error.
    """
    req_id = f"REQ-{datetime.now().strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:6].upper()}"
    print(f"\n{'═'*60}")
    print(f"  PIPELINE START   REQ-ID: {req_id}")
    print(f"{'═'*60}")

    state = PipelineState(user_prompt=user_prompt, req_id=req_id)
    timings = []

    for module_name, module_fn in MODULES:
        t0 = time.time()
        ok = True
        try:
            state = module_fn(state)
        except Exception as e:
            ok = False
            elapsed = (time.time() - t0) * 1000
            timings.append({"module": module_name, "ms": elapsed, "ok": False})
            DebugPoint.log_pipeline_summary(req_id, timings)
            raise RuntimeError(f"Pipeline failed at {module_name}: {e}") from e

        elapsed = (time.time() - t0) * 1000
        timings.append({"module": module_name, "ms": elapsed, "ok": ok})

    # ── Pipeline summary ─────────────────────────────────────────────
    DebugPoint.log_pipeline_summary(req_id, timings)
    _print_final_result(state)
    _save_output(state)

    return state


# ──────────────────────────────────────────────────────────────────────────────
# Output helpers
# ──────────────────────────────────────────────────────────────────────────────

def _print_final_result(state: PipelineState):
    v = state.validation
    d = state.document

    gate = "✓ PASS" if (v and v.passed_certification_gate) else "✗ FAIL"
    print(f"\n{'═'*60}")
    print(f"  FINAL RESULT")
    print(f"{'═'*60}")
    if d:
        print(f"  Domain         : {d.domain}  /  {d.sub_category}")
        print(f"  Sections       : {len(d.sections)}")
        print(f"  Fill gaps      : {len(d.fill_gaps)}")
        print(f"  Prompt version : {d.prompt_version}  |  Model: {d.model_used}")
    if v:
        print(f"  Confidence     : {v.confidence_score:.2f}")
        print(f"  Cert gate      : {gate}")
        print(f"  Issues         : {len(v.issues)}")
        print(f"  Summary        : {v.summary[:120]}...")
    print(f"{'═'*60}\n")


def _save_output(state: PipelineState):
    """Save the generated document to output/ directory."""
    if state.document is None:
        return

    out_dir = Path("output")
    out_dir.mkdir(exist_ok=True)

    filename = out_dir / f"{state.req_id}_{state.document.domain}_{state.document.sub_category}.md"
    filename.write_text(state.document.raw_markdown, encoding="utf-8")
    print(f"  📄 Document saved to: {filename}")


# ──────────────────────────────────────────────────────────────────────────────
# CLI entry point
# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Automotive Document Generation Pipeline")
    parser.add_argument(
        "--prompt",
        type=str,
        default="Create a software architecture description document for the Battery Management System at ASIL-B level.",
        help="User request prompt",
    )
    args = parser.parse_args()

    final_state = run_pipeline(args.prompt)
