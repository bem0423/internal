# Document AI Agent

Automated migration of SYS1 requirements documents from **UFS 4.1** to **UFS 5.0**.

The system reads the certified UFS 4.1 `.docx`, queries an internal RAG for the
matching UFS 5.0 content, and rewrites every chapter through a dedicated
AI agent. Each statement is tagged with its origin: `(UFS5.0)` when grounded
in the RAG, `(AI answer)` when inferred by the model.

## Architecture

Three-stage pipeline (see `document_ai_agent_architecture.png` for the diagram):

1. **Preprocessing** — extract the heading structure of the source `.docx` into
   `templates/template.md` and `templates/prompts.yaml`.
2. **AI Agent** — one `ChapterAgent` per chapter runs in parallel, calling the
   RAG and the LLM, then tagging each paragraph with its source.
3. **Postprocessing** — validate the generated markdown (structure,
   completeness, accuracy), re-run failed chapters, and convert the final
   markdown to `.docx`.

## Project layout

```
document_ai_agent/
├── previous_output/        # drop the UFS 4.1 .docx here
├── output/                 # final UFS 5.0 .docx + intermediate generated.md
├── templates/              # template.md, prompts.yaml (edit before agents run)
├── src/
│   ├── config.py
│   ├── tools.py
│   ├── preprocessing/
│   │   └── template_extractor.py
│   ├── agents/
│   │   ├── rag_client.py
│   │   ├── llm_client.py
│   │   ├── chapter_agent.py
│   │   └── agent_orchestrator.py
│   └── postprocessing/
│       ├── validator.py
│       └── doc_converter.py
├── tests/
│   └── test_pipeline.py
├── main.py
└── requirements.txt
```

## Quick start

```bash
# 1. Install
pip install -r requirements.txt

# 2. Configure secrets
export ANTHROPIC_API_KEY="..."
export RAG_ENDPOINT="https://internal-rag.company.com/api/query"
export RAG_API_KEY="..."

# 3. Put the source document in place
cp ufs41_sys1_requirements.docx previous_output/

# 4. Run end-to-end
python main.py
```

The first stage pauses after writing `templates/prompts.yaml`, giving you a
chance to tweak the per-chapter prompts before the agents start. Use
`--skip-prompt-edit` to skip the pause.

## Configuration

All knobs are environment-variable driven (see `src/config.py`):

| Variable | Default | Purpose |
|---|---|---|
| `ANTHROPIC_API_KEY` | _(required)_ | Auth for the LLM |
| `LLM_MODEL` | `claude-opus-4-7` | Model id |
| `LLM_MAX_TOKENS` | `4096` | Per-call output cap |
| `LLM_TEMPERATURE` | `0.3` | Generation temperature |
| `RAG_ENDPOINT` | _(must set)_ | Internal RAG HTTP endpoint |
| `RAG_API_KEY` | _(optional)_ | Bearer token for RAG |
| `RAG_TOP_K` | `5` | Hits per query |
| `RAG_SCORE_THRESHOLD` | `0.5` | Minimum similarity to count as a hit |
| `MAX_RETRY_COUNT` | `3` | Validation/regeneration loop budget |
| `MAX_CONCURRENT_AGENTS` | `5` | Parallelism cap |

## Testing

```bash
pytest -q
```

The smoke tests build a small in-memory `.docx`, exercise the preprocessing
and validation stages, and never call the LLM or RAG.

## Extending

- **Different RAG service** — edit `tools.rag_query`. The rest of the system
  uses the abstract `RAGClient`, so callers don't need to change.
- **Different LLM provider** — edit `src/agents/llm_client.py`.
- **Custom tagging policy** — edit `_apply_source_tagging` in
  `src/agents/chapter_agent.py` and the `Validator` checks in
  `src/postprocessing/validator.py` together.
