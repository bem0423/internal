"""Smoke tests for the Document AI Agent pipeline.

These tests avoid hitting the LLM or RAG endpoints. They focus on:
- template extraction from a synthesised .docx
- tools.create_table / spec_compare
- validator behaviour on good and bad markdown
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

# Make src/ importable when running pytest from project root.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from docx import Document as DocxDocument                                  # noqa: E402

from src.config import settings                                            # noqa: E402
from src.postprocessing.validator import Validator                         # noqa: E402
from src.preprocessing.template_extractor import build_template, load_prompts  # noqa: E402
from src.tools import create_table, extract_chapters_from_docx, spec_compare, validate_format  # noqa: E402


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _make_sample_docx(path: Path) -> None:
    """Build a tiny UFS-style .docx with two heading levels."""
    doc = DocxDocument()
    doc.add_heading("UFS 4.1 SYS1 Requirements", level=0)

    doc.add_heading("1. Introduction", level=1)
    doc.add_paragraph("This document defines the SYS1 requirements.")

    doc.add_heading("2. System Requirements", level=1)
    doc.add_paragraph("The system shall meet the following requirements.")

    doc.add_heading("2.1 Functional Requirements", level=2)
    doc.add_paragraph("The system shall support synchronous communication.")

    doc.add_heading("3. Interface Specification", level=1)
    doc.add_paragraph("Interfaces conform to the published spec.")

    doc.save(str(path))


# ---------------------------------------------------------------------------
# Preprocessing
# ---------------------------------------------------------------------------
def test_extract_chapters(tmp_path: Path) -> None:
    docx_path = tmp_path / "sample.docx"
    _make_sample_docx(docx_path)

    chapters = extract_chapters_from_docx(docx_path)
    numbers = [c.number for c in chapters]
    assert numbers == ["1", "2", "2.1", "3"]
    assert chapters[2].chapter_id == "ch_2_1"
    assert chapters[2].level == 2
    assert "synchronous" in chapters[2].raw_body


def test_build_template(tmp_path: Path) -> None:
    docx_path = tmp_path / "sample.docx"
    _make_sample_docx(docx_path)

    template_md = tmp_path / "template.md"
    prompts_yaml = tmp_path / "prompts.yaml"
    chapters, _, _ = build_template(docx_path, template_md, prompts_yaml)

    md = template_md.read_text(encoding="utf-8")
    assert "## 1 Introduction" in md
    assert "### 2.1 Functional Requirements" in md
    assert "[PROMPT_ID: ch_2_1]" in md

    prompts = load_prompts(prompts_yaml)
    assert set(prompts.keys()) == {c.chapter_id for c in chapters}
    assert prompts["ch_2_1"]["output_format"] == "table"


# ---------------------------------------------------------------------------
# tools.py
# ---------------------------------------------------------------------------
def test_create_table_pads_short_rows() -> None:
    md = create_table(
        ["A", "B", "C"],
        [["1", "2"], ["x", "y", "z", "ignored"]],
    )
    lines = md.splitlines()
    assert lines[0] == "| A | B | C |"
    assert lines[1] == "| --- | --- | --- |"
    assert lines[2] == "| 1 | 2 |  |"
    assert lines[3] == "| x | y | z |"


def test_spec_compare_detects_changes() -> None:
    diff = spec_compare("alpha\nbeta\ngamma", "alpha\nBETA\ngamma")
    assert 0 < diff["similarity"] < 1
    assert any(c["type"] == "replace" for c in diff["changes"])


def test_validate_format_flags_missing_tag() -> None:
    result = validate_format("This is a paragraph that says nothing tagged.")
    assert not result.passed
    assert any("source tag" in r for r in result.issues)


# ---------------------------------------------------------------------------
# Validator
# ---------------------------------------------------------------------------
def test_validator_pass_and_fail(tmp_path: Path) -> None:
    docx_path = tmp_path / "sample.docx"
    _make_sample_docx(docx_path)
    chapters = extract_chapters_from_docx(docx_path)
    validator = Validator(source_chapters=chapters, min_length=10)

    good_md = "\n\n".join(
        [
            "# UFS 5.0 SYS1 Requirements",
            "## 1 Introduction",
            f"This document defines SYS1 requirements. {settings.rag_hit_tag}",
            "## 2 System Requirements",
            f"The system shall comply with UFS 5.0. {settings.rag_hit_tag}",
            "### 2.1 Functional Requirements",
            f"Synchronous communication is supported. {settings.rag_hit_tag}",
            "## 3 Interface Specification",
            f"Interfaces conform to UFS 5.0. {settings.rag_hit_tag}",
        ]
    )
    assert validator.validate(good_md).passed is True

    bad_md = "\n\n".join(
        [
            "# UFS 5.0 SYS1 Requirements",
            "## 1 Introduction",
            "Too short.",                       # missing tag, too short
            "## 2 System Requirements",
            f"OK content. {settings.rag_hit_tag}",
            "### 2.1 Functional Requirements",
            f"OK content. {settings.rag_hit_tag}",
            # chapter 3 missing entirely
        ]
    )
    report = validator.validate(bad_md)
    assert report.passed is False
    assert "ch_1" in report.failed_chapter_ids
    assert "ch_3" in report.failed_chapter_ids
