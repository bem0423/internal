"""Create a synthetic UFS 4.1 SYS1 .docx for demos and integration runs."""
from pathlib import Path

from docx import Document

PROJECT_ROOT = Path(__file__).resolve().parent.parent
OUT = PROJECT_ROOT / "previous_output" / "ufs41_sys1_requirements.docx"
OUT.parent.mkdir(parents=True, exist_ok=True)

doc = Document()
doc.add_heading("UFS 4.1 SYS1 Requirements", level=0)

doc.add_heading("1. Introduction", level=1)
doc.add_paragraph(
    "This document specifies the SYS1 requirements certified under UFS 4.1. "
    "It defines the functional, performance, and interface requirements."
)

doc.add_heading("2. System Requirements", level=1)
doc.add_paragraph(
    "The system shall meet all applicable UFS 4.1 requirements as defined "
    "in the UFS Working Group specifications."
)

doc.add_heading("2.1 Functional Requirements", level=2)
doc.add_paragraph(
    "The system shall support synchronous bus communication. "
    "Maximum payload size shall not exceed 1024 bytes."
)

doc.add_heading("2.2 Performance Requirements", level=2)
doc.add_paragraph(
    "Read latency shall be less than 50 microseconds at nominal load. "
    "Throughput shall reach 800 MB/s sustained."
)

doc.add_heading("3. Interface Specification", level=1)
doc.add_paragraph(
    "The host interface shall conform to UFS 4.1 transport layer specifications."
)

doc.save(str(OUT))
print(f"Wrote {OUT}")
