"""
main.py - end-to-end orchestration of the Document AI Agent.

Pipeline
--------
1. Preprocessing
   - Read the .docx from previous_output/
   - Emit templates/template.md and templates/prompts.yaml
   - (optional) Pause so the user can edit prompts.yaml
2. AI Agent
   - Spin up one ChapterAgent per chapter
   - Run them concurrently, gather results
3. Postprocessing
   - Combine results into generated.md
   - Validate; re-run failed chapters up to MAX_RETRY_COUNT
   - Convert the validated markdown to .docx

Usage
-----
    python main.py                          # run end-to-end
    python main.py --skip-prompt-edit       # don't wait for user edits
    python main.py --source path/to.docx    # override source location
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import sys
from pathlib import Path
from typing import List, Sequence

from src.agents.agent_orchestrator import AgentOrchestrator, combine_results
from src.config import settings
from src.postprocessing.doc_converter import convert_to_docx
from src.postprocessing.validator import Validator
from src.preprocessing.template_extractor import (
    build_template,
    load_prompts,
    run_preprocessing,
)
from src.tools import Chapter

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------
def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Document AI Agent")
    parser.add_argument(
        "--source",
        type=Path,
        default=None,
        help="Override the source .docx location (defaults to previous_output/*.docx).",
    )
    parser.add_argument(
        "--skip-prompt-edit",
        action="store_true",
        help="Don't pause between preprocessing and the agent stage.",
    )
    parser.add_argument(
        "--max-retries",
        type=int,
        default=settings.max_retry_count,
        help="Maximum validation/regeneration loops.",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
    )
    return parser.parse_args()


# ---------------------------------------------------------------------------
# Stages
# ---------------------------------------------------------------------------
def stage_preprocess(source: Path | None):
    if source is not None:
        template_md = settings.template_dir / "template.md"
        prompts_yaml = settings.template_dir / "prompts.yaml"
        chapters, _, _ = build_template(source, template_md, prompts_yaml)
        return chapters, template_md, prompts_yaml
    return run_preprocessing()


async def stage_agents(
    chapters: Sequence[Chapter], prompts_yaml: Path
) -> List:
    prompts = load_prompts(prompts_yaml)
    orchestrator = AgentOrchestrator(chapters=chapters, prompts=prompts)
    return await orchestrator.run_all(), orchestrator


async def stage_validation_loop(
    chapters: Sequence[Chapter],
    results: List,
    orchestrator: AgentOrchestrator,
    max_retries: int,
) -> tuple[List, Path]:
    """Combine -> validate -> re-run failed chapters -> repeat."""
    validator = Validator(source_chapters=chapters)
    generated_md_path = settings.output_dir / "generated.md"

    attempt = 0
    while True:
        # Re-run combine each loop because results may have been replaced.
        combine_results(results, generated_md_path)
        generated_md = generated_md_path.read_text(encoding="utf-8")
        report = validator.validate(generated_md)

        if report.passed:
            logger.info("Validation passed on attempt %d.", attempt + 1)
            return results, generated_md_path

        logger.warning("%s", report.summary())
        if attempt >= max_retries:
            logger.error(
                "Max retries (%d) reached; proceeding with current output.",
                max_retries,
            )
            return results, generated_md_path

        attempt += 1
        logger.info(
            "Retry %d/%d - re-running %d failed chapter(s).",
            attempt,
            max_retries,
            len(report.failed_chapter_ids),
        )
        new_results = await orchestrator.rerun_chapters(report.failed_chapter_ids)
        results = _replace_results(results, new_results)


def _replace_results(existing, new):
    """Replace any results whose chapter_id matches one in `new`."""
    by_id = {r.chapter_id: r for r in existing}
    for r in new:
        by_id[r.chapter_id] = r
    return list(by_id.values())


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------
async def run(args: argparse.Namespace) -> int:
    print("=" * 60)
    print(f"Document AI Agent: {settings.source_spec_version} -> {settings.target_spec_version}")
    print("=" * 60)

    # 1. Preprocessing
    print("\n[1/3] Preprocessing: extracting template...")
    chapters, template_md, prompts_yaml = stage_preprocess(args.source)
    print(f"      -> {len(chapters)} chapter(s) extracted")
    print(f"      -> template:  {template_md}")
    print(f"      -> prompts:   {prompts_yaml}")

    if not args.skip_prompt_edit:
        print(
            f"\n    Review/edit '{prompts_yaml}' if you want to customise the "
            "per-chapter prompts."
        )
        try:
            input("    Press Enter when ready to continue... ")
        except EOFError:
            pass

    # 2. AI Agent stage
    print("\n[2/3] Running AI agents in parallel...")
    results, orchestrator = await stage_agents(chapters, prompts_yaml)
    print(f"      -> {len(results)} chapter result(s)")

    # 3. Validation loop + conversion
    print("\n[3/3] Validation loop...")
    results, generated_md_path = await stage_validation_loop(
        chapters, results, orchestrator, max_retries=args.max_retries
    )
    print(f"      -> generated markdown: {generated_md_path}")

    print("\nConverting to .docx...")
    final_docx = convert_to_docx(generated_md_path)
    print(f"      -> final document:     {final_docx}")

    print("\nDone.")
    return 0


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main() -> int:
    args = parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)-7s %(name)s :: %(message)s",
    )
    return asyncio.run(run(args))


if __name__ == "__main__":
    sys.exit(main())
