"""
Global configuration for the Document AI Agent.

All paths, model settings, RAG endpoints, and runtime parameters
are centralized here so they can be overridden by environment variables.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List


# Project root: the directory that contains src/, previous_output/, etc.
PROJECT_ROOT = Path(__file__).resolve().parent.parent


@dataclass
class Settings:
    # -------- Paths --------
    project_root: Path = PROJECT_ROOT
    previous_output_dir: Path = PROJECT_ROOT / "previous_output"
    output_dir: Path = PROJECT_ROOT / "output"
    template_dir: Path = PROJECT_ROOT / "templates"

    # -------- LLM --------
    llm_provider: str = os.getenv("LLM_PROVIDER", "anthropic")
    llm_model: str = os.getenv("LLM_MODEL", "claude-opus-4-7")
    llm_max_tokens: int = int(os.getenv("LLM_MAX_TOKENS", "4096"))
    llm_temperature: float = float(os.getenv("LLM_TEMPERATURE", "0.3"))
    anthropic_api_key: str = os.getenv("ANTHROPIC_API_KEY", "")

    # -------- Internal RAG --------
    rag_endpoint: str = os.getenv(
        "RAG_ENDPOINT", "http://internal-rag.company.com/api/query"
    )
    rag_api_key: str = os.getenv("RAG_API_KEY", "")
    rag_top_k: int = int(os.getenv("RAG_TOP_K", "5"))
    rag_score_threshold: float = float(os.getenv("RAG_SCORE_THRESHOLD", "0.5"))
    rag_timeout_seconds: int = int(os.getenv("RAG_TIMEOUT_SECONDS", "30"))

    # -------- Spec version tags --------
    source_spec_version: str = "UFS 4.1"
    target_spec_version: str = "UFS 5.0"
    rag_hit_tag: str = "(UFS5.0)"
    rag_miss_tag: str = "(AI answer)"

    # -------- Validation --------
    max_retry_count: int = int(os.getenv("MAX_RETRY_COUNT", "3"))
    min_chapter_length: int = int(os.getenv("MIN_CHAPTER_LENGTH", "50"))
    required_keywords: List[str] = field(default_factory=lambda: ["shall", "requirement"])

    # -------- Orchestration --------
    max_concurrent_agents: int = int(os.getenv("MAX_CONCURRENT_AGENTS", "5"))

    def ensure_dirs(self) -> None:
        """Create runtime directories if they don't exist."""
        for d in (self.previous_output_dir, self.output_dir, self.template_dir):
            d.mkdir(parents=True, exist_ok=True)


# Singleton-style accessor
settings = Settings()
settings.ensure_dirs()
