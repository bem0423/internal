"""
tools.py - shared utilities used across pre/processing/post stages.

Functions
---------
- rag_query: query the internal RAG service
- create_table / render_markdown_table: produce markdown tables
- spec_compare: diff between UFS 4.1 and UFS 5.0 texts
- md_to_docx: convert a markdown file into a styled Word document
- validate_format: lightweight format checks (source tagging, tables)
- extract_chapters_from_docx: parse heading structure from a .docx
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import requests
from docx import Document as DocxDocument
from docx.shared import Pt

from src.config import settings

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------
@dataclass
class Chapter:
    """A single chapter extracted from the source .docx."""

    chapter_id: str              # e.g. "ch_2_1"
    number: str                  # e.g. "2.1"
    title: str                   # e.g. "Functional Requirements"
    level: int                   # heading level (1, 2, 3, ...)
    raw_body: str = ""           # original body text (used by agents)


@dataclass
class RAGResult:
    """One hit from the internal RAG service."""

    text: str
    score: float
    source: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ValidationResult:
    passed: bool
    failed_chapters: List[str] = field(default_factory=list)
    issues: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# RAG client
# ---------------------------------------------------------------------------
def rag_query(
    query: str,
    top_k: Optional[int] = None,
    spec_version: Optional[str] = None,
) -> List[RAGResult]:
    """Send a query to the internal RAG service and return ranked hits.

    Returns an empty list if the call fails or no hit meets the score
    threshold. Callers use the empty list as the trigger for the
    'AI answer' fallback path.
    """
    top_k = top_k or settings.rag_top_k
    payload = {"query": query, "top_k": top_k}
    if spec_version:
        payload["spec_version"] = spec_version

    headers = {"Content-Type": "application/json"}
    if settings.rag_api_key:
        headers["Authorization"] = f"Bearer {settings.rag_api_key}"

    try:
        resp = requests.post(
            settings.rag_endpoint,
            json=payload,
            headers=headers,
            timeout=settings.rag_timeout_seconds,
        )
        resp.raise_for_status()
        data = resp.json()
    except requests.RequestException as exc:
        logger.warning("RAG call failed (%s): %s", query, exc)
        return []
    except ValueError as exc:
        logger.warning("RAG response was not valid JSON (%s): %s", query, exc)
        return []

    results: List[RAGResult] = []
    for hit in data.get("results", []):
        score = float(hit.get("score", 0.0))
        if score < settings.rag_score_threshold:
            continue
        results.append(
            RAGResult(
                text=hit.get("text", ""),
                score=score,
                source=hit.get("source", ""),
                metadata=hit.get("metadata", {}),
            )
        )
    return results


# ---------------------------------------------------------------------------
# Table helpers
# ---------------------------------------------------------------------------
def create_table(headers: Sequence[str], rows: Sequence[Sequence[Any]]) -> str:
    """Build a GitHub-flavoured markdown table.

    Each row is padded/truncated to match the number of headers so the
    output is always well-formed.
    """
    if not headers:
        raise ValueError("create_table requires at least one header")

    header_line = "| " + " | ".join(str(h) for h in headers) + " |"
    separator = "| " + " | ".join("---" for _ in headers) + " |"
    body_lines = []
    n = len(headers)
    for row in rows:
        cells = list(row) + [""] * (n - len(row))
        cells = cells[:n]
        body_lines.append("| " + " | ".join(str(c) for c in cells) + " |")
    return "\n".join([header_line, separator, *body_lines])


def render_markdown_table(data: List[Dict[str, Any]]) -> str:
    """Render a list-of-dicts as a markdown table.

    Column order is determined by the keys of the first row.
    """
    if not data:
        return ""
    headers = list(data[0].keys())
    rows = [[row.get(h, "") for h in headers] for row in data]
    return create_table(headers, rows)


# ---------------------------------------------------------------------------
# Spec comparison
# ---------------------------------------------------------------------------
def spec_compare(ufs41_text: str, ufs50_text: str) -> Dict[str, Any]:
    """Compute a similarity ratio and a line-level diff between two specs."""
    ratio = SequenceMatcher(None, ufs41_text, ufs50_text).ratio()

    old_lines = ufs41_text.splitlines()
    new_lines = ufs50_text.splitlines()
    matcher = SequenceMatcher(None, old_lines, new_lines)

    changes: List[Dict[str, Any]] = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue
        changes.append(
            {
                "type": tag,                      # 'replace' | 'delete' | 'insert'
                "old": "\n".join(old_lines[i1:i2]),
                "new": "\n".join(new_lines[j1:j2]),
            }
        )
    return {"similarity": ratio, "changes": changes}


# ---------------------------------------------------------------------------
# Chapter extraction from .docx
# ---------------------------------------------------------------------------
_HEADING_NUMBER_RE = re.compile(r"^\s*(\d+(?:\.\d+)*)\.?\s+(.*)$")


def _heading_level(style_name: str) -> Optional[int]:
    """Return the heading level (1-based) for a python-docx style name."""
    if not style_name:
        return None
    match = re.match(r"Heading\s+(\d+)", style_name)
    if match:
        return int(match.group(1))
    return None


def extract_chapters_from_docx(docx_path: Path) -> List[Chapter]:
    """Walk a .docx file and produce a flat list of Chapter objects.

    A chapter is created for every paragraph whose style is 'Heading N'.
    Body paragraphs between headings are concatenated into ``raw_body``
    of the most recent chapter so each agent has the original text
    available.
    """
    doc = DocxDocument(str(docx_path))
    chapters: List[Chapter] = []
    current: Optional[Chapter] = None

    for para in doc.paragraphs:
        text = para.text.strip()
        level = _heading_level(para.style.name if para.style else "")

        if level is not None and text:
            number, title = _split_number_and_title(text)
            chapter = Chapter(
                chapter_id=_make_chapter_id(number),
                number=number,
                title=title,
                level=level,
            )
            chapters.append(chapter)
            current = chapter
        elif text and current is not None:
            current.raw_body = (current.raw_body + "\n" + text).strip()

    return chapters


def _split_number_and_title(text: str) -> Tuple[str, str]:
    """Split '2.1 Functional Requirements' -> ('2.1', 'Functional Requirements')."""
    match = _HEADING_NUMBER_RE.match(text)
    if match:
        return match.group(1), match.group(2).strip()
    return "", text


def _make_chapter_id(number: str) -> str:
    """'2.1' -> 'ch_2_1'. Falls back to a slug when number is empty."""
    if not number:
        return "ch_unnumbered"
    return "ch_" + number.replace(".", "_")


# ---------------------------------------------------------------------------
# Format validation (lightweight, structural)
# ---------------------------------------------------------------------------
def validate_format(content: str, rules: Optional[Dict[str, Any]] = None) -> ValidationResult:
    """Run quick checks: source tags present, tables well-formed, etc.

    Heavier semantic validation lives in postprocessing/validator.py.
    """
    rules = rules or {}
    required_tags: Iterable[str] = rules.get(
        "required_tags", [settings.rag_hit_tag, settings.rag_miss_tag]
    )
    min_length: int = rules.get("min_length", settings.min_chapter_length)

    issues: List[str] = []
    if len(content.strip()) < min_length:
        issues.append(f"content shorter than {min_length} characters")

    if not any(tag in content for tag in required_tags):
        issues.append("no source tag found (expected one of: " + ", ".join(required_tags) + ")")

    # Sanity check: every markdown table row should start and end with '|'
    for i, line in enumerate(content.splitlines(), start=1):
        stripped = line.strip()
        if stripped.startswith("|") and not stripped.endswith("|"):
            issues.append(f"line {i}: malformed table row")

    return ValidationResult(passed=not issues, issues=issues)


# ---------------------------------------------------------------------------
# MD -> DOCX conversion
# ---------------------------------------------------------------------------
_MD_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)$")
_TABLE_SEPARATOR_RE = re.compile(r"^\s*\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)+\|?\s*$")


def md_to_docx(
    md_path: Path,
    docx_path: Path,
    style_template: Optional[Path] = None,
) -> None:
    """Convert a markdown file into a Word document.

    The converter handles the subset of markdown that the agents actually
    produce: ATX headings, paragraphs, and pipe tables. If a
    ``style_template`` is given, its styles (fonts, headings) are inherited
    via python-docx's template mechanism.
    """
    if style_template and style_template.exists():
        doc = DocxDocument(str(style_template))
        # Clear body but keep styles & section properties
        for para in list(doc.paragraphs):
            p = para._element
            p.getparent().remove(p)
        for table in list(doc.tables):
            t = table._element
            t.getparent().remove(t)
    else:
        doc = DocxDocument()

    md_text = Path(md_path).read_text(encoding="utf-8")
    lines = md_text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if not stripped:
            i += 1
            continue

        heading = _MD_HEADING_RE.match(stripped)
        if heading:
            level = min(len(heading.group(1)), 9)
            doc.add_heading(heading.group(2).strip(), level=level)
            i += 1
            continue

        # Table detection: header line followed by separator
        if stripped.startswith("|") and i + 1 < len(lines) and _TABLE_SEPARATOR_RE.match(lines[i + 1]):
            consumed = _add_table_from_md(doc, lines, i)
            i += consumed
            continue

        doc.add_paragraph(stripped)
        i += 1

    docx_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(docx_path))


def _add_table_from_md(doc, lines: List[str], start: int) -> int:
    """Consume a markdown table starting at lines[start]; return rows consumed."""
    header_cells = _split_md_row(lines[start])
    # lines[start + 1] is the separator; skip it.
    i = start + 2
    body_rows: List[List[str]] = []
    while i < len(lines) and lines[i].strip().startswith("|"):
        body_rows.append(_split_md_row(lines[i]))
        i += 1

    n_cols = len(header_cells)
    table = doc.add_table(rows=1 + len(body_rows), cols=n_cols)
    table.style = "Table Grid"

    for c, cell_text in enumerate(header_cells):
        cell = table.rows[0].cells[c]
        cell.text = cell_text
        for run in cell.paragraphs[0].runs:
            run.bold = True
            run.font.size = Pt(11)

    for r, row in enumerate(body_rows, start=1):
        for c in range(n_cols):
            text = row[c] if c < len(row) else ""
            table.rows[r].cells[c].text = text

    return i - start


def _split_md_row(line: str) -> List[str]:
    """Split a markdown table row, dropping the leading/trailing pipes."""
    stripped = line.strip()
    if stripped.startswith("|"):
        stripped = stripped[1:]
    if stripped.endswith("|"):
        stripped = stripped[:-1]
    return [cell.strip() for cell in stripped.split("|")]
