"""
agent_orchestrator.py - run a ChapterAgent per chapter, in parallel.

The orchestrator caps concurrency (settings.max_concurrent_agents) so
we don't overwhelm the LLM or RAG endpoints, then re-assembles the
results into a single markdown document that mirrors template.md.
"""
from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

from src.agents.chapter_agent import ChapterAgent, ChapterResult
from src.agents.llm_client import LLMClient
from src.agents.rag_client import RAGClient
from src.config import settings
from src.tools import Chapter

logger = logging.getLogger(__name__)


class AgentOrchestrator:
    """Coordinate parallel execution of all chapter agents."""

    def __init__(
        self,
        chapters: Sequence[Chapter],
        prompts: Dict[str, Dict[str, Any]],
        rag_client: Optional[RAGClient] = None,
        llm_client: Optional[LLMClient] = None,
        max_concurrency: Optional[int] = None,
    ) -> None:
        self.chapters = list(chapters)
        self.prompts = prompts
        self.rag_client = rag_client or RAGClient()
        self.llm_client = llm_client or LLMClient()
        self.semaphore = asyncio.Semaphore(
            max_concurrency or settings.max_concurrent_agents
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    async def run_all(self) -> List[ChapterResult]:
        """Run every chapter's agent and return the results in chapter order."""
        tasks = [self._run_one(ch) for ch in self.chapters]
        return await asyncio.gather(*tasks)

    async def rerun_chapters(
        self, chapter_ids: Iterable[str]
    ) -> List[ChapterResult]:
        """Re-run only the specified chapters (used by the validation loop)."""
        target = {cid for cid in chapter_ids}
        tasks = [self._run_one(ch) for ch in self.chapters if ch.chapter_id in target]
        return await asyncio.gather(*tasks)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    async def _run_one(self, chapter: Chapter) -> ChapterResult:
        prompt_config = self.prompts.get(chapter.chapter_id, {})
        agent = ChapterAgent(
            chapter=chapter,
            prompt_config=prompt_config,
            rag_client=self.rag_client,
            llm_client=self.llm_client,
        )
        async with self.semaphore:
            try:
                return await agent.run()
            except Exception as exc:                # pragma: no cover - defensive
                logger.exception(
                    "[%s] agent crashed: %s", chapter.chapter_id, exc
                )
                return ChapterResult(
                    chapter_id=chapter.chapter_id,
                    chapter_number=chapter.number,
                    chapter_title=chapter.title,
                    level=chapter.level,
                    content_md=(
                        f"_Agent failed: {exc.__class__.__name__}. "
                        f"Manual review required._ {settings.rag_miss_tag}"
                    ),
                    rag_used=False,
                    metadata={"error": str(exc)},
                )


# ----------------------------------------------------------------------
# Combine results into a single markdown document
# ----------------------------------------------------------------------
def combine_results(
    results: Sequence[ChapterResult],
    output_path: Optional[Path] = None,
) -> str:
    """Stitch all chapter outputs back together into one markdown doc."""
    parts: List[str] = [f"# {settings.target_spec_version} SYS1 Requirements", ""]

    # Sort results to match the source order: 1, 1.1, 1.2, 2, 2.1, ...
    sorted_results = sorted(results, key=_chapter_sort_key)

    for r in sorted_results:
        heading_marks = "#" * (r.level + 1)
        prefix = f"{r.chapter_number} " if r.chapter_number else ""
        parts.append(f"{heading_marks} {prefix}{r.chapter_title}".rstrip())
        parts.append("")
        parts.append(r.content_md)
        parts.append("")

    document = "\n".join(parts).rstrip() + "\n"
    if output_path is not None:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(document, encoding="utf-8")
    return document


def _chapter_sort_key(result: ChapterResult) -> List[int]:
    """Sort '2.10' AFTER '2.2' by comparing numeric components."""
    if not result.chapter_number:
        return [10**9]                            # unnumbered chapters last
    try:
        return [int(p) for p in result.chapter_number.split(".")]
    except ValueError:
        return [10**9]
