"""
chapter_agent.py - one Agent per chapter.

Each Agent:
1. Reads the previous (UFS 4.1) body for its chapter
2. Queries the internal RAG for matching UFS 5.0 content
3. Asks the LLM to update the body, using RAG results as grounding
4. Tags every paragraph with either (UFS5.0) or (AI answer)
5. Delegates table rendering to tools.create_table when needed
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

from src.agents.llm_client import LLMClient
from src.agents.rag_client import RAGClient
from src.config import settings
from src.tools import Chapter, RAGResult, create_table

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------
@dataclass
class ChapterResult:
    chapter_id: str
    chapter_number: str
    chapter_title: str
    level: int
    content_md: str                              # rendered chapter body (no heading)
    source_tags: List[str] = field(default_factory=list)
    has_table: bool = False
    rag_used: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------
class ChapterAgent:
    """An LLM-backed agent that owns a single chapter end-to-end."""

    def __init__(
        self,
        chapter: Chapter,
        prompt_config: Dict[str, Any],
        rag_client: RAGClient,
        llm_client: LLMClient,
    ) -> None:
        self.chapter = chapter
        self.prompt_config = prompt_config or {}
        self.rag_client = rag_client
        self.llm_client = llm_client

    # ---- main entry point ---------------------------------------------------
    async def run(self) -> ChapterResult:
        """Execute the 4-step pipeline described in the architecture doc."""
        logger.info("[%s] running agent", self.chapter.chapter_id)

        # STEP 1 + 2 — previous_output is already in chapter.raw_body
        previous_body = self.chapter.raw_body

        # STEP 3 — query RAG for UFS 5.0 mapping
        rag_query_text = self.prompt_config.get(
            "rag_query",
            f"{settings.target_spec_version} {self.chapter.title}",
        )
        rag_hits = await self.rag_client.query(
            rag_query_text, spec_version=settings.target_spec_version
        )
        rag_used = bool(rag_hits)

        # STEP 4 — ask the LLM to produce the updated body
        output_format = self.prompt_config.get("output_format", "paragraph")
        body_md = await self._generate_body(previous_body, rag_hits, output_format)

        # STEP 5 — enforce source tagging
        body_md, tags = self._apply_source_tagging(body_md, rag_used=rag_used)

        # STEP 6 — if a table is expected, make sure one is present
        has_table = "|" in body_md and "---" in body_md
        if output_format == "table" and not has_table:
            body_md = self._fallback_empty_table(rag_used) + "\n\n" + body_md
            has_table = True

        return ChapterResult(
            chapter_id=self.chapter.chapter_id,
            chapter_number=self.chapter.number,
            chapter_title=self.chapter.title,
            level=self.chapter.level,
            content_md=body_md.strip(),
            source_tags=tags,
            has_table=has_table,
            rag_used=rag_used,
            metadata={"rag_hit_count": len(rag_hits)},
        )

    # ---- LLM call -----------------------------------------------------------
    async def _generate_body(
        self,
        previous_body: str,
        rag_hits: Sequence[RAGResult],
        output_format: str,
    ) -> str:
        system_prompt = self._build_system_prompt(output_format)
        user_prompt = self._build_user_prompt(previous_body, rag_hits, output_format)
        try:
            return await self.llm_client.complete(system_prompt, user_prompt)
        except Exception as exc:
            logger.error("[%s] LLM failed: %s", self.chapter.chapter_id, exc)
            # Graceful fallback so the orchestrator can still move on.
            return (
                f"_LLM call failed for this chapter ({exc.__class__.__name__}). "
                f"Manual review required._ {settings.rag_miss_tag}"
            )

    # ---- prompt construction ------------------------------------------------
    def _build_system_prompt(self, output_format: str) -> str:
        return (
            "You are a technical-writing agent migrating a SYS1 requirements "
            f"document from {settings.source_spec_version} to "
            f"{settings.target_spec_version}.\n\n"
            "Rules:\n"
            f"1. End every paragraph or row with one of these tags: "
            f"'{settings.rag_hit_tag}' when grounded in the RAG context, or "
            f"'{settings.rag_miss_tag}' when you had to infer.\n"
            "2. Preserve the technical meaning of the previous content unless "
            "the new spec contradicts it.\n"
            f"3. Output format: {output_format}. If 'table', return a valid "
            "GitHub-flavoured markdown table.\n"
            "4. Do NOT include a heading; output only the body of the chapter.\n"
            "5. Be concise and write in formal English."
        )

    def _build_user_prompt(
        self,
        previous_body: str,
        rag_hits: Sequence[RAGResult],
        output_format: str,
    ) -> str:
        instruction = self.prompt_config.get(
            "instruction",
            f"Update this chapter to {settings.target_spec_version}.",
        )
        rag_block = self._format_rag_context(rag_hits)
        table_hint = ""
        if output_format == "table":
            cols = self.prompt_config.get(
                "table_columns",
                ["Req ID", settings.source_spec_version, settings.target_spec_version, "Change Type"],
            )
            table_hint = (
                "\n\nProduce a markdown table with these columns: "
                + ", ".join(cols)
                + "."
            )

        return (
            f"## Chapter\n{self.chapter.number} {self.chapter.title}\n\n"
            f"## Instruction\n{instruction}{table_hint}\n\n"
            f"## Previous content ({settings.source_spec_version})\n"
            f"{previous_body or '(empty)'}\n\n"
            f"## Retrieved context\n{rag_block}\n\n"
            "## Task\nWrite the updated chapter body now."
        )

    @staticmethod
    def _format_rag_context(rag_hits: Sequence[RAGResult]) -> str:
        if not rag_hits:
            return "(no RAG matches; rely on inference and tag with (AI answer))"
        lines = []
        for i, hit in enumerate(rag_hits, start=1):
            src = f" — source: {hit.source}" if hit.source else ""
            lines.append(f"[{i}] (score {hit.score:.2f}){src}\n{hit.text}")
        return "\n\n".join(lines)

    # ---- source tagging -----------------------------------------------------
    _PARAGRAPH_SPLIT_RE = re.compile(r"\n\s*\n")

    def _apply_source_tagging(
        self, body_md: str, *, rag_used: bool
    ) -> tuple[str, List[str]]:
        """Make sure every paragraph ends with exactly one source tag.

        Markdown tables are left untouched; the LLM is instructed to put
        tags inside cells when relevant. For everything else we walk the
        paragraphs and append a tag if none is present.
        """
        default_tag = settings.rag_hit_tag if rag_used else settings.rag_miss_tag
        used_tags: set[str] = set()
        out_blocks: List[str] = []

        for block in self._PARAGRAPH_SPLIT_RE.split(body_md.strip()):
            stripped = block.strip()
            if not stripped:
                continue

            if stripped.startswith("|") or stripped.startswith("#"):
                # Tables and stray headings pass through untouched.
                out_blocks.append(stripped)
                # Record any tags already inside table cells.
                for tag in (settings.rag_hit_tag, settings.rag_miss_tag):
                    if tag in stripped:
                        used_tags.add(tag)
                continue

            if (
                settings.rag_hit_tag not in stripped
                and settings.rag_miss_tag not in stripped
            ):
                stripped = f"{stripped} {default_tag}"

            for tag in (settings.rag_hit_tag, settings.rag_miss_tag):
                if tag in stripped:
                    used_tags.add(tag)
            out_blocks.append(stripped)

        return "\n\n".join(out_blocks), sorted(used_tags)

    # ---- fallback when LLM forgets to emit a table -------------------------
    def _fallback_empty_table(self, rag_used: bool) -> str:
        headers = self.prompt_config.get(
            "table_columns",
            ["Req ID", settings.source_spec_version, settings.target_spec_version, "Change Type"],
        )
        tag = settings.rag_hit_tag if rag_used else settings.rag_miss_tag
        placeholder_row = ["TBD"] * (len(headers) - 1) + [f"Manual review {tag}"]
        return create_table(headers, [placeholder_row])
