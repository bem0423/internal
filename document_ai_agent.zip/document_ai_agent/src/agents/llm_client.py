"""
llm_client.py - minimal async wrapper around the Anthropic Messages API.

Why this module exists
----------------------
Agents need to call an LLM but should not care about the SDK or auth
details. Swapping providers later (internal LLM, OpenAI, etc.) means
editing one file.
"""
from __future__ import annotations

import asyncio
import logging
from typing import List, Optional

from src.config import settings

logger = logging.getLogger(__name__)


class LLMClient:
    """Thin async wrapper around anthropic.Anthropic().messages.create."""

    def __init__(
        self,
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
    ) -> None:
        self.model = model or settings.llm_model
        self.max_tokens = max_tokens or settings.llm_max_tokens
        self.temperature = (
            temperature if temperature is not None else settings.llm_temperature
        )
        self._client = self._build_client()

    # -------- internals --------
    def _build_client(self):
        """Lazily import anthropic so test environments without the SDK don't break."""
        try:
            import anthropic
        except ImportError as exc:                # pragma: no cover - env-specific
            raise RuntimeError(
                "The 'anthropic' package is required. Install with: pip install anthropic"
            ) from exc

        if not settings.anthropic_api_key:
            logger.warning(
                "ANTHROPIC_API_KEY is not set; LLM calls will fail at runtime."
            )
        return anthropic.Anthropic(api_key=settings.anthropic_api_key or None)

    # -------- public API --------
    async def complete(
        self,
        system_prompt: str,
        user_prompt: str,
    ) -> str:
        """Send a single-turn message and return the assistant text."""

        def _call() -> str:
            response = self._client.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}],
            )
            # Concatenate all text blocks (the API can return multiple).
            parts: List[str] = []
            for block in response.content:
                if getattr(block, "type", None) == "text":
                    parts.append(block.text)
            return "\n".join(parts).strip()

        try:
            return await asyncio.to_thread(_call)
        except Exception as exc:                  # pragma: no cover - defensive
            logger.exception("LLM call failed: %s", exc)
            raise
