"""
rag_client.py - thin async wrapper around tools.rag_query.

Agents call this through asyncio.to_thread to avoid blocking the event
loop while many chapters are processed in parallel.
"""
from __future__ import annotations

import asyncio
import logging
from typing import List, Optional

from src.config import settings
from src.tools import RAGResult, rag_query

logger = logging.getLogger(__name__)


class RAGClient:
    """Async-friendly wrapper that delegates to the synchronous rag_query."""

    def __init__(self, top_k: Optional[int] = None) -> None:
        self.top_k = top_k or settings.rag_top_k

    async def query(
        self,
        text: str,
        spec_version: Optional[str] = None,
    ) -> List[RAGResult]:
        """Run rag_query in a worker thread so callers can await it."""
        try:
            return await asyncio.to_thread(
                rag_query, text, self.top_k, spec_version
            )
        except Exception as exc:                  # pragma: no cover - defensive
            logger.exception("RAGClient.query failed: %s", exc)
            return []
