"""
template_extractor.py - turn a UFS 4.1 .docx into a chapter-only template.

Pipeline
--------
1. Read the source .docx from previous_output/
2. Extract heading hierarchy (number + title) using tools.extract_chapters_from_docx
3. Emit two artifacts:
   - templates/template.md   : structural skeleton with [PROMPT_ID: ...] slots
   - templates/prompts.yaml  : editable per-chapter prompt configuration
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List, Tuple

import yaml

from src.config import settings
from src.tools import Chapter, extract_chapters_from_docx

logger = logging.getLogger(__name__)


def build_template(
    source_docx: Path,
    template_md_path: Path,
    prompts_yaml_path: Path,
) -> Tuple[List[Chapter], Path, Path]:
    """Create template.md and prompts.yaml from the source document.

    Returns the chapter list and the output paths so the caller can
    chain the result into the agent stage.
    """
    if not source_docx.exists():
        raise FileNotFoundError(f"Source .docx not found: {source_docx}")

    chapters = extract_chapters_from_docx(source_docx)
    if not chapters:
        raise ValueError(
            f"No headings (Heading 1/2/3...) were found in {source_docx}. "
            "Make sure the document uses Word heading styles."
        )

    _write_template_md(chapters, template_md_path)
    _write_prompts_yaml(chapters, prompts_yaml_path)

    logger.info(
        "Template built: %d chapters -> %s, %s",
        len(chapters),
        template_md_path,
        prompts_yaml_path,
    )
    return chapters, template_md_path, prompts_yaml_path


# ---------------------------------------------------------------------------
# template.md
# ---------------------------------------------------------------------------
def _write_template_md(chapters: List[Chapter], path: Path) -> None:
    """Write a markdown skeleton: headings + a prompt slot under each."""
    lines: List[str] = [f"# {settings.target_spec_version} SYS1 Requirements", ""]
    for chapter in chapters:
        heading_marks = "#" * (chapter.level + 1)   # +1 so doc title stays the top-level
        prefix = f"{chapter.number} " if chapter.number else ""
        lines.append(f"{heading_marks} {prefix}{chapter.title}".rstrip())
        lines.append(f"[PROMPT_ID: {chapter.chapter_id}]")
        lines.append("")

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


# ---------------------------------------------------------------------------
# prompts.yaml
# ---------------------------------------------------------------------------
def _write_prompts_yaml(chapters: List[Chapter], path: Path) -> None:
    """Write a fully populated, but easily editable, prompts file."""
    prompts: Dict[str, Dict[str, object]] = {}
    for chapter in chapters:
        prompts[chapter.chapter_id] = _default_prompt_for_chapter(chapter)

    payload = {"prompts": prompts}
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        yaml.safe_dump(
            payload,
            f,
            allow_unicode=True,
            sort_keys=False,
            default_flow_style=False,
        )


def _default_prompt_for_chapter(chapter: Chapter) -> Dict[str, object]:
    """Heuristic default prompt for a chapter.

    Users are expected to edit prompts.yaml before running the agent stage;
    these defaults just give them a reasonable starting point.
    """
    chapter_label = (
        f"{chapter.number} {chapter.title}".strip() if chapter.number else chapter.title
    )

    # Very small heuristic: chapters whose title hints at tabular content
    # default to output_format=table.
    title_lower = chapter.title.lower()
    looks_tabular = any(
        k in title_lower
        for k in ("requirement", "specification", "matrix", "mapping", "interface")
    )

    config: Dict[str, object] = {
        "chapter": chapter_label,
        "instruction": (
            f"Update the content of '{chapter_label}' from "
            f"{settings.source_spec_version} to {settings.target_spec_version}. "
            "Query the internal RAG for the latest spec text and apply changes. "
            "Append the appropriate source tag at the end of each statement: "
            f"'{settings.rag_hit_tag}' when RAG returned matching content, "
            f"or '{settings.rag_miss_tag}' when the content was inferred."
        ),
        "rag_query": f"{settings.target_spec_version} {chapter.title}",
        "output_format": "table" if looks_tabular else "paragraph",
    }
    if looks_tabular:
        config["table_columns"] = [
            "Req ID",
            settings.source_spec_version,
            settings.target_spec_version,
            "Change Type",
        ]
    return config


# ---------------------------------------------------------------------------
# Convenience: load prompts back from disk
# ---------------------------------------------------------------------------
def load_prompts(prompts_yaml_path: Path) -> Dict[str, Dict[str, object]]:
    """Read prompts.yaml and return the per-chapter prompt dict."""
    with prompts_yaml_path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    return data.get("prompts", {})


# ---------------------------------------------------------------------------
# Module-level entry point
# ---------------------------------------------------------------------------
def run_preprocessing() -> Tuple[List[Chapter], Path, Path]:
    """Find the first .docx in previous_output/ and process it."""
    candidates = sorted(settings.previous_output_dir.glob("*.docx"))
    if not candidates:
        raise FileNotFoundError(
            f"No .docx file found in {settings.previous_output_dir}. "
            "Place the UFS 4.1 source document there first."
        )
    source = candidates[0]
    template_md = settings.template_dir / "template.md"
    prompts_yaml = settings.template_dir / "prompts.yaml"
    return build_template(source, template_md, prompts_yaml)
