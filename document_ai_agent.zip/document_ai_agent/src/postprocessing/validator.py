"""
validator.py - verify the generated markdown before producing the .docx.

Three categories of checks (mirroring the architecture diagram):
- Structural   : every source chapter present in the same order
- Completeness : no empty chapters; minimum length per chapter
- Accuracy     : every chapter carries a source tag; tables are well-formed
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Dict, List, Sequence

from src.config import settings
from src.tools import Chapter

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------
@dataclass
class ChapterIssue:
    chapter_id: str
    chapter_number: str
    chapter_title: str
    reasons: List[str] = field(default_factory=list)


@dataclass
class ValidationReport:
    passed: bool
    failed_chapter_ids: List[str] = field(default_factory=list)
    chapter_issues: List[ChapterIssue] = field(default_factory=list)
    global_issues: List[str] = field(default_factory=list)

    def summary(self) -> str:
        if self.passed:
            return "Validation passed."
        lines = [
            f"Validation failed ({len(self.failed_chapter_ids)} chapter(s) need rework)."
        ]
        for issue in self.chapter_issues:
            label = f"{issue.chapter_number} {issue.chapter_title}".strip()
            lines.append(f"  - [{issue.chapter_id}] {label}: " + "; ".join(issue.reasons))
        for g in self.global_issues:
            lines.append(f"  ! {g}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Validator
# ---------------------------------------------------------------------------
_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)$")
_TABLE_SEPARATOR_RE = re.compile(r"^\s*\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)+\|?\s*$")


class Validator:
    """Compare the generated markdown against the source chapter list."""

    def __init__(
        self,
        source_chapters: Sequence[Chapter],
        min_length: int = None,
        required_keywords: List[str] = None,
    ) -> None:
        self.source_chapters = list(source_chapters)
        self.min_length = (
            min_length if min_length is not None else settings.min_chapter_length
        )
        self.required_keywords = required_keywords or []

    # ----- public ------------------------------------------------------
    def validate(self, generated_md: str) -> ValidationReport:
        parsed = _parse_chapters(generated_md)
        report = ValidationReport(passed=True)

        # Structural: every source chapter must appear
        parsed_map: Dict[str, str] = {c["chapter_id"]: c["body"] for c in parsed}
        seen_ids = set(parsed_map.keys())
        expected_ids = [c.chapter_id for c in self.source_chapters]
        missing = [cid for cid in expected_ids if cid not in seen_ids]
        for cid in missing:
            ch = next(c for c in self.source_chapters if c.chapter_id == cid)
            self._fail(report, ch, "chapter is missing from generated output")

        # Per-chapter checks
        for chapter in self.source_chapters:
            if chapter.chapter_id in missing:
                continue
            body = parsed_map.get(chapter.chapter_id, "")
            reasons: List[str] = []

            if len(body.strip()) < self.min_length:
                reasons.append(
                    f"too short ({len(body.strip())} < {self.min_length} chars)"
                )

            if not _has_source_tag(body):
                reasons.append("missing source tag (UFS5.0 / AI answer)")

            for issue in _table_issues(body):
                reasons.append(issue)

            if self.required_keywords and not _has_any_keyword(body, self.required_keywords):
                reasons.append(
                    "no required keyword found ("
                    + ", ".join(self.required_keywords)
                    + ")"
                )

            if reasons:
                self._fail_with_reasons(report, chapter, reasons)

        report.passed = not report.failed_chapter_ids
        return report

    # ----- helpers -----------------------------------------------------
    def _fail(self, report: ValidationReport, chapter: Chapter, reason: str) -> None:
        self._fail_with_reasons(report, chapter, [reason])

    def _fail_with_reasons(
        self, report: ValidationReport, chapter: Chapter, reasons: List[str]
    ) -> None:
        if chapter.chapter_id not in report.failed_chapter_ids:
            report.failed_chapter_ids.append(chapter.chapter_id)
        report.chapter_issues.append(
            ChapterIssue(
                chapter_id=chapter.chapter_id,
                chapter_number=chapter.number,
                chapter_title=chapter.title,
                reasons=reasons,
            )
        )


# ---------------------------------------------------------------------------
# Markdown parsing helpers
# ---------------------------------------------------------------------------
def _parse_chapters(md: str) -> List[Dict[str, str]]:
    """Walk the markdown and return a list of {chapter_id, body} dicts.

    Recognises the same numbering scheme used by template_extractor:
    a heading like '## 2.1 Functional Requirements' yields chapter_id 'ch_2_1'.
    The document-level H1 is ignored.
    """
    chapters: List[Dict[str, str]] = []
    current: Dict[str, str] = None
    body_lines: List[str] = []

    for line in md.splitlines():
        heading = _HEADING_RE.match(line.strip())
        if heading:
            level = len(heading.group(1))
            text = heading.group(2).strip()
            if level == 1:
                # Document title; flush in case we were already in a chapter.
                if current is not None:
                    current["body"] = "\n".join(body_lines).strip()
                    chapters.append(current)
                    current = None
                    body_lines = []
                continue
            # Close previous chapter
            if current is not None:
                current["body"] = "\n".join(body_lines).strip()
                chapters.append(current)
                body_lines = []
            # Open new chapter
            number, title = _split_number_title(text)
            current = {
                "chapter_id": _make_chapter_id(number),
                "number": number,
                "title": title,
                "body": "",
            }
        else:
            if current is not None:
                body_lines.append(line)

    if current is not None:
        current["body"] = "\n".join(body_lines).strip()
        chapters.append(current)

    return chapters


def _split_number_title(text: str) -> tuple[str, str]:
    match = re.match(r"^(\d+(?:\.\d+)*)\.?\s+(.*)$", text)
    if match:
        return match.group(1), match.group(2).strip()
    return "", text


def _make_chapter_id(number: str) -> str:
    if not number:
        return "ch_unnumbered"
    return "ch_" + number.replace(".", "_")


def _has_source_tag(text: str) -> bool:
    return settings.rag_hit_tag in text or settings.rag_miss_tag in text


def _has_any_keyword(text: str, keywords: List[str]) -> bool:
    low = text.lower()
    return any(k.lower() in low for k in keywords)


def _table_issues(text: str) -> List[str]:
    """Detect malformed tables: header without separator, ragged rows, etc."""
    issues: List[str] = []
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith("|"):
            # Expect a separator on the next line
            if i + 1 >= len(lines) or not _TABLE_SEPARATOR_RE.match(lines[i + 1]):
                issues.append(f"table at line {i + 1} is missing a separator row")
                break
            header_cols = _count_cells(line)
            j = i + 2
            while j < len(lines) and lines[j].strip().startswith("|"):
                row_cols = _count_cells(lines[j].strip())
                if row_cols != header_cols:
                    issues.append(
                        f"table row at line {j + 1} has {row_cols} cells, "
                        f"expected {header_cols}"
                    )
                j += 1
            i = j
        else:
            i += 1
    return issues


def _count_cells(row: str) -> int:
    stripped = row.strip()
    if stripped.startswith("|"):
        stripped = stripped[1:]
    if stripped.endswith("|"):
        stripped = stripped[:-1]
    return len([c for c in stripped.split("|")])
