"""
doc_converter.py - wrap tools.md_to_docx so the postprocessing pipeline has
a single, obvious entry point and a place to apply final-stage tweaks
(metadata, file naming, etc.).
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from src.config import settings
from src.tools import md_to_docx

logger = logging.getLogger(__name__)


def convert_to_docx(
    generated_md_path: Path,
    output_docx_path: Optional[Path] = None,
    style_template: Optional[Path] = None,
) -> Path:
    """Convert the validated markdown into the final .docx artifact.

    If ``style_template`` is not supplied, the first .docx in
    previous_output/ is used so the final document inherits the original
    document's font and heading styles.
    """
    if output_docx_path is None:
        stem = generated_md_path.stem.replace("generated", "ufs50_sys1_requirements")
        output_docx_path = settings.output_dir / f"{stem}.docx"

    if style_template is None:
        candidates = sorted(settings.previous_output_dir.glob("*.docx"))
        style_template = candidates[0] if candidates else None

    md_to_docx(generated_md_path, output_docx_path, style_template=style_template)
    logger.info("Final document written to %s", output_docx_path)
    return output_docx_path
